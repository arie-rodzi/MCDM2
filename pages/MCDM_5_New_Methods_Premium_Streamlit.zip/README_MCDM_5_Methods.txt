# Premium MCDM Learning Modules

Contains 5 new Streamlit files: AHP, TOPSIS, VIKOR, CRITIC and DEMATEL. SAW is not included because it was already created separately.

Run example:
streamlit run 01_AHP_Method.py
